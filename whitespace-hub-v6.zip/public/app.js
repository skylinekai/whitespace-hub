/* Whitespace Hub front end: navigation, search, favourites and the form renderer. */
(function () {
  'use strict';
  const $ = (s, el = document) => el.querySelector(s);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const h = (tag, attrs = {}, ...kids) => {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const k of kids.flat()) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(k));
    return el;
  };

  // ---------- icons (Fluent-style, 20px) ----------
  const P = {
    home: 'M8.5 2.6a2.2 2.2 0 0 1 3 0l5.3 4.6c.4.4.7.9.7 1.5v7.1c0 1-.8 1.7-1.7 1.7h-2.6c-1 0-1.7-.8-1.7-1.7v-3.3a.5.5 0 0 0-.5-.5H9a.5.5 0 0 0-.5.5v3.3c0 1-.8 1.7-1.7 1.7H4.2c-1 0-1.7-.8-1.7-1.7V8.7c0-.6.3-1.1.7-1.5l5.3-4.6Zm2.3.8a1.2 1.2 0 0 0-1.6 0L3.9 8a1 1 0 0 0-.4.7v7.1c0 .4.3.7.7.7h2.6c.4 0 .7-.3.7-.7v-3.3c0-.8.7-1.5 1.5-1.5h2c.8 0 1.5.7 1.5 1.5v3.3c0 .4.3.7.7.7h2.6c.4 0 .7-.3.7-.7V8.7a1 1 0 0 0-.4-.7l-5.3-4.6Z',
    folder: 'M2 6c0-1.1.9-2 2-2h3.6c.4 0 .8.1 1.1.4L10.2 6H16c1.1 0 2 .9 2 2v6.5c0 1.1-.9 2-2 2H4a2 2 0 0 1-2-2V6Zm2-1a1 1 0 0 0-1 1v1h5.6l1.2-1.2-1.5-1.1a.8.8 0 0 0-.5-.2H4Zm-1 3v6.5c0 .6.4 1 1 1h12c.6 0 1-.4 1-1V8c0-.6-.4-1-1-1h-5.8L9.4 8.8a1 1 0 0 1-.7.2H3Z',
    star: 'M9.1 2.9a1 1 0 0 1 1.8 0l1.9 3.8 4.2.6a1 1 0 0 1 .5 1.7l-3 3 .7 4.2a1 1 0 0 1-1.4 1L10 15.2l-3.8 2a1 1 0 0 1-1.4-1l.7-4.2-3-3a1 1 0 0 1 .5-1.7l4.2-.6 1.9-3.8Zm.9.4L8.1 7.2a1 1 0 0 1-.8.5l-4.3.7 3.1 3a1 1 0 0 1 .3.9l-.7 4.3 3.8-2a1 1 0 0 1 1 0l3.8 2-.7-4.3a1 1 0 0 1 .3-.9l3.1-3-4.3-.7a1 1 0 0 1-.8-.5L10 3.3Z',
    starOn: 'M9.1 2.9a1 1 0 0 1 1.8 0l1.9 3.8 4.2.6a1 1 0 0 1 .5 1.7l-3 3 .7 4.2a1 1 0 0 1-1.4 1L10 15.2l-3.8 2a1 1 0 0 1-1.4-1l.7-4.2-3-3a1 1 0 0 1 .5-1.7l4.2-.6 1.9-3.8Z',
    search: 'M8.5 3a5.5 5.5 0 0 1 4.4 8.8l4 4a.5.5 0 0 1-.7.7l-4-4A5.5 5.5 0 1 1 8.5 3Zm0 1a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9Z',
    x: 'm4.1 4.2.1-.1a.5.5 0 0 1 .6 0l.1.1L10 9.3l5.1-5.2a.5.5 0 0 1 .8.7L10.7 10l5.2 5.1c.2.2.2.5 0 .7l-.1.1a.5.5 0 0 1-.6 0l-.1-.1L10 10.7l-5.1 5.2a.5.5 0 0 1-.8-.7L9.3 10 4.1 4.9a.5.5 0 0 1 0-.7Z',
    back: 'M9.2 16.4a.5.5 0 0 0 .7-.7L4.7 10.5H16.5a.5.5 0 0 0 0-1H4.7l5.2-5.2a.5.5 0 0 0-.7-.7L3.1 9.6a.5.5 0 0 0 0 .8l6.1 6Z',
    chev: 'M7.6 4.1a.5.5 0 0 1 .7 0l5.5 5.5c.2.2.2.6 0 .8l-5.5 5.5a.5.5 0 0 1-.7-.7l5.1-5.2-5.1-5.2a.5.5 0 0 1 0-.7Z',
    form: 'M6 2a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V7.4c0-.4-.2-.8-.4-1.1l-3.9-3.9c-.3-.2-.7-.4-1.1-.4H6ZM5 4c0-.6.4-1 1-1h4v3.5c0 .8.7 1.5 1.5 1.5H15v8c0 .6-.4 1-1 1H6a1 1 0 0 1-1-1V4Zm9.8 3h-3.3a.5.5 0 0 1-.5-.5V3.2L14.8 7ZM7 10.5c0-.3.2-.5.5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5Zm0 2c0-.3.2-.5.5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5Zm0 2c0-.3.2-.5.5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5Z',
    info: 'M10 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16Zm0 1a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm0 5.5c.3 0 .5.2.5.5v4.5a.5.5 0 0 1-1 0V9c0-.3.2-.5.5-.5Zm0-2.3a.8.8 0 1 1 0 1.6.8.8 0 0 1 0-1.6Z',
    err: 'M10 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16Zm0 10.5a.8.8 0 1 0 0 1.6.8.8 0 0 0 0-1.6ZM10 6a.5.5 0 0 0-.5.4v4.6a.5.5 0 0 0 1 0V6.5A.5.5 0 0 0 10 6Z',
    check: 'M10 2a8 8 0 1 1 0 16 8 8 0 0 1 0-16Zm3.4 5.1-.1.1-4.1 4.5-1.8-1.8a.5.5 0 0 0-.8.7l2.2 2.1c.2.2.6.2.8 0l4.4-4.9a.5.5 0 0 0-.6-.7Z',
    upload: 'M15.5 17a.5.5 0 0 0 0-1h-11a.5.5 0 0 0 0 1h11ZM10.1 3h-.2l-.2.1-4 4a.5.5 0 0 0 .6.8L9.5 4.7v9.8a.5.5 0 0 0 1 0V4.7l3.1 3.1a.5.5 0 0 0 .8-.7l-4-4-.3-.1Z',
    menu: 'M2.5 4h15a.5.5 0 0 1 .1 1h-15a.5.5 0 0 1-.1-1h15-15Zm0 5.5h15a.5.5 0 0 1 .1 1h-15a.5.5 0 0 1-.1-1h15-15Zm0 5.5h15a.5.5 0 0 1 .1 1h-15a.5.5 0 0 1-.1-1h15-15Z',
    open: 'M6 4a2 2 0 0 0-2 2v8c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2v-2.5a.5.5 0 0 0-1 0V14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6c0-.6.4-1 1-1h2.5a.5.5 0 0 0 0-1H6Zm5.5 0a.5.5 0 0 0 0 1h2.8l-4.6 4.6a.5.5 0 0 0 .7.7L15 5.7v2.8a.5.5 0 0 0 1 0v-4a.5.5 0 0 0-.5-.5h-4Z',
    inbox: 'M5.4 3h9.2c.9 0 1.6.6 1.9 1.4l1.4 5.3v4.8c0 1.4-1.1 2.5-2.5 2.5h-11A2.5 2.5 0 0 1 2 14.5V9.7l1.4-5.3C3.7 3.6 4.5 3 5.4 3Zm0 1a1 1 0 0 0-1 .7L3.2 9H7c.3 0 .5.2.5.5a2.5 2.5 0 0 0 5 0c0-.3.2-.5.5-.5h3.8l-1.2-4.3a1 1 0 0 0-1-.7H5.4ZM3 10v4.5c0 .8.7 1.5 1.5 1.5h11c.8 0 1.5-.7 1.5-1.5V10h-3.5a3.5 3.5 0 0 1-7 0H3Z',
    bolt: 'M7.4 2.3c.1-.2.3-.3.5-.3h5.6c.4 0 .6.4.5.7L12.4 7H15c.4 0 .7.5.4.8l-7.5 9.6c-.3.4-1 .1-.9-.4l1.2-5.5H5.5a.5.5 0 0 1-.5-.6l2.4-8.6ZM8.3 3 6.1 10.5h2.7c.3 0 .5.3.5.6l-.9 4.1L14 8H11.6a.5.5 0 0 1-.4-.7L12.7 3H8.3Z',
    leaf: 'M16.5 3.1c.3 0 .5.3.5.5 0 5.4-1.6 9-4 11.1A7.4 7.4 0 0 1 4.5 16l-.9 1.7a.5.5 0 0 1-.9-.4l.9-1.8C2.4 12.7 3 9.5 5.2 7.2 7.6 4.8 11.5 3.3 16.5 3.1Zm-.5 1c-4.5.3-8 1.7-10 3.8-1.9 2-2.4 4.7-1 7.1l.6-1.1C7 11 9.4 9 12.6 7.6a.5.5 0 0 1 .4.9C9.9 9.9 7.6 11.8 6 14.7l-.6 1.1c2.3 1 5 .6 7-1.1 2.1-1.8 3.5-5 3.6-10.6Z',
    people: 'M7.5 3a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm-2 3a2 2 0 1 1 4 0 2 2 0 0 1-4 0ZM14 5a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm-1 2a1 1 0 1 1 2 0 1 1 0 0 1-2 0ZM3.5 10C2.7 10 2 10.7 2 11.5v.3c0 1.6 1.9 3.2 5.5 3.2s5.5-1.6 5.5-3.2v-.3c0-.8-.7-1.5-1.5-1.5h-8ZM3 11.5c0-.3.2-.5.5-.5h8c.3 0 .5.2.5.5v.3c0 .9-1.3 2.2-4.5 2.2S3 12.7 3 11.8v-.3Zm11 2.5c-.6 0-1.2-.1-1.7-.2.2-.3.4-.6.5-1h1.2c2.2 0 3-1 3-1.6v-.2c0-.3-.2-.5-.5-.5h-2.6c-.1-.4-.3-.7-.6-1H16.5c.8 0 1.5.7 1.5 1.5v.2C18 12.6 16.6 14 14 14Z',
    signout: 'M8.5 11.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5ZM11 3.5c0-.3-.2-.5-.5-.5H5.6c-.9 0-1.6.7-1.6 1.6v10.8c0 .9.7 1.6 1.6 1.6h4.9c.3 0 .5-.2.5-.5V3.5ZM10 4v12H5.6a.6.6 0 0 1-.6-.6V4.6c0-.3.3-.6.6-.6H10Zm3.9 3.1a.5.5 0 0 1 .7 0l2.6 2.5c.2.2.2.6 0 .8l-2.6 2.5a.5.5 0 0 1-.7-.7l1.8-1.7H12.5a.5.5 0 0 1 0-1h3.2l-1.8-1.7a.5.5 0 0 1 0-.7Z',
    key: 'M12.5 2a5.5 5.5 0 0 1 0 11c-.5 0-.9 0-1.4-.2L9.9 14H8.5v1.5c0 .3-.2.5-.5.5H6.5v1.5c0 .3-.2.5-.5.5H2.5a.5.5 0 0 1-.5-.5v-2.3c0-.4.2-.8.4-1.1l4.8-4.8A5.5 5.5 0 0 1 12.5 2Zm0 1a4.5 4.5 0 0 0-4.3 5.9l.1.3-.2.2-5 5-.1.4V17h3v-1.5c0-.3.2-.5.5-.5h1.5v-1.5c0-.3.2-.5.5-.5h1.8l1.3-1.3.3.1A4.5 4.5 0 1 0 12.5 3ZM14 5a1 1 0 1 1 0 2 1 1 0 0 1 0-2Z',
    more: 'M6.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0Zm5 0a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0ZM15 11.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5Z',
    add: 'M10 3a.5.5 0 0 1 .5.5v6h6a.5.5 0 0 1 0 1h-6v6a.5.5 0 0 1-1 0v-6h-6a.5.5 0 0 1 0-1h6v-6c0-.3.2-.5.5-.5Z',
    up: 'M9.6 3.1c.2-.2.6-.2.8 0l5.5 5.5a.5.5 0 0 1-.7.7L10.5 4.7v11.8a.5.5 0 0 1-1 0V4.7L4.9 9.3a.5.5 0 0 1-.7-.7l5.4-5.5Z',
    down: 'M10.4 16.9c-.2.2-.6.2-.8 0l-5.5-5.5a.5.5 0 0 1 .7-.7l4.7 4.6V3.5a.5.5 0 0 1 1 0v11.8l4.6-4.6a.5.5 0 0 1 .7.7l-5.4 5.5Z',
    del: 'M8.5 4h3a1.5 1.5 0 0 0-3 0Zm-1 0a2.5 2.5 0 0 1 5 0h4a.5.5 0 0 1 0 1h-.6l-1.2 10.4A2.5 2.5 0 0 1 12.2 18H7.8a2.5 2.5 0 0 1-2.5-2.2L4.1 5h-.6a.5.5 0 0 1 0-1h4Zm-2.2 11.7c.1.8.7 1.3 1.5 1.3h4.4c.8 0 1.4-.5 1.5-1.3L14.9 5H5.1l1.2 10.7ZM8.5 7.5c.3 0 .5.2.5.5v6a.5.5 0 0 1-1 0V8c0-.3.2-.5.5-.5ZM12 8a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V8Z',
    palette: 'M10 2a8 8 0 0 0 0 16c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.2 0-1.1.9-2 2-2h1.5A3.5 3.5 0 0 0 18 8a6 6 0 0 0-8-6Zm0 1c3.9 0 7 2.4 7 5 0 1.4-1.1 2.5-2.5 2.5H13a3 3 0 0 0-3 3c0 .7.3 1.3.7 1.8.2.2.3.4.3.7 0 .6-.4 1-1 1a7 7 0 0 1 0-14Zm-4 6a1 1 0 1 0 0 2 1 1 0 0 0 0-2Zm2-3a1 1 0 1 0 0 2 1 1 0 0 0 0-2Zm4 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z',
    tick: 'M7.9 13.9 4.4 10.4a.6.6 0 0 1 .8-.9l3.1 3.1 6.5-6.5a.6.6 0 1 1 .8.9l-6.9 6.9a.6.6 0 0 1-.8 0Z',
    cal: 'M14.5 3A2.5 2.5 0 0 1 17 5.5v9a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 3 14.5v-9A2.5 2.5 0 0 1 5.5 3h9ZM16 7H4v7.5c0 .8.7 1.5 1.5 1.5h9c.8 0 1.5-.7 1.5-1.5V7Zm-1.5-3h-9C4.7 4 4 4.7 4 5.5V6h12v-.5c0-.8-.7-1.5-1.5-1.5Z',
    person: 'M10 2a4 4 0 1 1 0 8 4 4 0 0 1 0-8Zm0 1a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm-5 9h10a2 2 0 0 1 2 2c0 1.7-.8 2.9-2.1 3.7-1.2.8-2.9 1.3-4.9 1.3s-3.7-.5-4.9-1.3A4.2 4.2 0 0 1 3 14c0-1.1.9-2 2-2Zm0 1a1 1 0 0 0-1 1c0 1.3.6 2.2 1.6 2.9 1 .7 2.6 1.1 4.4 1.1s3.4-.4 4.4-1.1c1-.7 1.6-1.6 1.6-2.9a1 1 0 0 0-1-1H5Z',
    megaphone: 'M15.5 3.1c.3.1.5.4.5.7v12.4a.8.8 0 0 1-1.1.7L10.7 15H9.5l.8 2.4a.5.5 0 0 1-.5.6H7.6a.5.5 0 0 1-.5-.3L6 15H5a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3h5.7l4.2-1.9a.8.8 0 0 1 .6 0ZM15 4.2 11 6v8l4 1.8V4.2ZM10 6H5a2 2 0 0 0-2 2v4c0 1.1.9 2 2 2h5V6Zm-1.6 9H7.1l.9 2h1.1l-.7-2Zm9.1-7.5a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-1 0V8c0-.3.2-.5.5-.5Z',
    pin: 'M12.8 2.4a1.5 1.5 0 0 0-2.4.4L8.6 6.5 5 7.6a1 1 0 0 0-.4 1.7l2.5 2.5-3.9 3.9a.5.5 0 0 0 .7.7l3.9-3.9 2.5 2.5a1 1 0 0 0 1.7-.4l1.1-3.6 3.7-1.8a1.5 1.5 0 0 0 .4-2.4l-4.4-4.4Zm-1.5.9a.5.5 0 0 1 .8-.2l4.4 4.4c.3.3.2.7-.2.8l-3.9 2c-.1 0-.2.2-.3.3l-1.2 3.8L5.5 9l3.8-1.2.3-.3 2-3.9Z',
    copy: 'M8 2a2 2 0 0 0-2 2v10c0 1.1.9 2 2 2h6a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8ZM7 4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V4ZM4 6a2 2 0 0 1 1-1.7V14.5A2.5 2.5 0 0 0 7.5 17h6.2a2 2 0 0 1-1.7 1H7.5A3.5 3.5 0 0 1 4 14.5V6Z',
    rename: 'M14.2 2.9a2 2 0 0 1 2.9 2.9l-9.4 9.4c-.3.3-.6.5-1 .6l-3.6 1.2a.5.5 0 0 1-.6-.6l1.2-3.6c.1-.4.3-.7.6-1l9.9-9.9Zm2.2.7a1 1 0 0 0-1.5 0l-.9 1 1.5 1.4.9-.9a1 1 0 0 0 0-1.5Zm-1.6 3.1-1.4-1.5-8 8-.3.4-.8 2.4 2.4-.8.4-.3 7.7-8.2Z',
    undo: 'M4.5 3a.5.5 0 0 1 .5.5v3.3A7 7 0 1 1 3 10.5a.5.5 0 0 1 1 0 6 6 0 1 0 1.8-4.3H8.5a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5v-4c0-.3.2-.5.5-.5Z',
    eraser: 'M11.2 3.4a2 2 0 0 1 2.8 0l2.6 2.6a2 2 0 0 1 0 2.8L10.4 15H16.5a.5.5 0 0 1 0 1H8.1a2 2 0 0 1-1.5-.6L3.4 12.2a2 2 0 0 1 0-2.8l7.8-6Zm-2.5 4L4.1 10a1 1 0 0 0 0 1.4l3.2 3.2c.4.4 1 .4 1.4 0l3.6-3.6-3.6-3.6Z'
  };
  const icon = (n, cls = 'i') => `<svg class="${cls}" viewBox="0 0 20 20" aria-hidden="true"><path d="${P[n]}"/></svg>`;
  const iconEl = (n, cls) => { const s = h('span'); s.innerHTML = icon(n, cls); return s.firstChild; };

  // ---------- data (loaded from the server; admins can change it) ----------
  let HUB = null, DEPTS = [], byDept = {}, ITEMS = [], formDept = {}, HOME = [], MORE = [], FORM_LIST = [];
  const FORMS = {};   // form definitions, fetched as needed
  function setHub(doc) {
    HUB = doc; DEPTS = doc.departments; byDept = Object.fromEntries(DEPTS.map(d => [d.id, d]));
    HOME = DEPTS.filter(d => d.group !== 'more'); MORE = DEPTS.filter(d => d.group === 'more');
    ITEMS = []; formDept = {};
    DEPTS.forEach(d => d.sections.forEach(s => s.items.forEach(it => {
      if (it.kind === 'note') return;
      const type = it.kind;
      const url = type === 'form' ? '#form/' + it.formId : type === 'page' ? '#d/' + it.target : it.url;
      const ext = type === 'doc' ? ((it.fileName || url.split('?')[0]).split('.').pop() || '').toLowerCase() : type;
      ITEMS.push({ key: type === 'form' ? 'form:' + it.formId : 'item:' + it.id, oldKey: type + ':' + url, type, t: it.title, url, m: it.sub || '', ext, dept: d, sec: s, it, formId: type === 'form' ? it.formId : null });
    })));
    ITEMS.filter(i => i.formId).forEach(i => { formDept[i.formId] = formDept[i.formId] || i; });
    // favourites saved before items had IDs
    if (favs.some(k => /^(doc|link|app):/.test(k))) { favs = favs.map(k => (ITEMS.find(x => x.oldKey === k) || { key: k }).key); store.set('wsh-favs', favs); }
  }
  async function loadHub() {
    const r = await fetch('/api/hub');
    if (r.status === 401) { toLogin(); throw new Error('signed out'); }
    if (!r.ok) throw new Error('hub');
    setHub(await r.json());
  }
  async function loadFormList() { try { const r = await fetch('/api/forms'); if (r.ok) FORM_LIST = await r.json(); } catch { } return FORM_LIST; }
  async function getForm(id, fresh) {
    if (FORMS[id] && !fresh) return FORMS[id];
    const r = await fetch('/api/forms/' + encodeURIComponent(id));
    if (r.status === 401) { toLogin(); throw new Error('signed out'); }
    if (r.status === 404) return null;
    if (!r.ok) throw new Error('form');
    return (FORMS[id] = await r.json());
  }

  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { } },
    del(k) { try { localStorage.removeItem(k); } catch { } }
  };
  let favs = store.get('wsh-favs', []);
  let ME = null;
  const isAdminMe = () => !!ME && ME.role === 'admin';
  const toLogin = () => location.replace('/login?next=' + encodeURIComponent(location.pathname + location.search) + location.hash);

  // ---------- shell ----------
  const pane = $('#pane'), q = $('#q'), folders = $('#folders');
  const fitSearch = () => { q.placeholder = innerWidth < 600 ? 'Search' : 'Search forms, policies and documents'; };
  fitSearch(); addEventListener('resize', fitSearch);
  const counts = d => ITEMS.filter(x => x.dept === d && x.type !== 'page').length;

  let activeFolder = 'home';
  function renderFolders(active) {
    activeFolder = active;
    const f = (href, label, ic, n, cur, color, dept) => `<a class="folder" href="${href}"${cur ? ' aria-current="page"' : ''}${dept ? ` data-dept="${dept}"${isAdminMe() ? ` title="${esc(label)} – right-click for options"` : ''}` : ''}>${color ? `<span class="cat" style="background:${color}"></span>` : icon(ic, 'i ic')}<span class="lbl">${esc(label)}</span>${n ? `<span class="n">${n}</span>` : ''}${dept && EDIT ? `<button class="fmore" type="button" data-act="dept-menu" data-dept="${dept}" aria-label="Options for ${esc(label)}">${icon('more')}</button>` : ''}</a>`;
    const apps = ITEMS.filter(x => x.type === 'app');
    folders.innerHTML =
      f('#home', 'Dashboard', 'home', '', active === 'home') +
      f('#fav', 'Favourites', 'star', favs.length || '', active === 'fav') +
      `<div class="grp">Departments</div>` +
      HOME.map(d => f('#d/' + d.id, d.name, null, counts(d), active === d.id, d.color, d.id)).join('') +
      (EDIT ? `<button class="folder addf" type="button" data-act="dept-add" data-group="main">${icon('add', 'i ic')}<span class="lbl">New folder</span></button>` : '') +
      (MORE.length || EDIT ? `<div class="grp">More</div>` + MORE.map(d => f('#d/' + d.id, d.name, null, counts(d) || '', active === d.id, d.color, d.id)).join('') : '') +
      (EDIT ? `<button class="folder addf" type="button" data-act="dept-add" data-group="more">${icon('add', 'i ic')}<span class="lbl">New folder in More</span></button>` : '') +
      (apps.length ? `<div class="grp">Apps</div>` + apps.map(x => `<a class="folder" href="${esc(x.url)}">${icon('leaf', 'i ic')}<span class="lbl">${esc(x.t)}</span></a>`).join('') : '') +
      (isAdminMe() ? `<div class="grp">Admin</div>` + `<a class="folder" href="/admin">${icon('inbox', 'i ic')}<span class="lbl">Submissions</span></a>` + `<a class="folder" href="/admin#users">${icon('people', 'i ic')}<span class="lbl">Users</span></a>` : '');
  }
  const scrim = h('div', { class: 'scrim', hidden: true, onclick: () => toggleMenu(false) });
  document.body.append(scrim);
  function toggleMenu(open) { folders.classList.toggle('open', open); scrim.hidden = !open; $('#menuBtn').setAttribute('aria-expanded', open); }
  $('#menuBtn').addEventListener('click', () => toggleMenu(!folders.classList.contains('open')));

  // ---------- rows ----------
  const hl = (s, term) => { s = esc(s); if (!term) return s; const i = s.toLowerCase().indexOf(term.toLowerCase()); return i < 0 ? s : s.slice(0, i) + '<mark>' + s.slice(i, i + term.length) + '</mark>' + s.slice(i + term.length); };
  const KIND = { form: 'Form', app: 'App', link: 'Link', page: 'Page', pdf: 'PDF', docx: 'Word', doc: 'Word', xlsx: 'Excel', pptx: 'PowerPoint', png: 'Image', jpg: 'Image', jpeg: 'Image', mp4: 'Video' };
  const BADGE = { form: icon('form'), app: icon('leaf'), link: icon('open'), page: icon('chev') };
  function row(x, { where = false, term = '' } = {}) {
    if (EDIT && !where) return editRow(x);
    const fav = favs.includes(x.key);
    const ext = x.type === 'doc' ? x.ext : x.type;
    const badge = BADGE[ext] || esc((x.ext || 'file').toUpperCase().slice(0, 4));
    const external = x.type === 'doc' || x.type === 'link';
    return `<div class="row">
      <span class="ft ${esc(ext)}" aria-hidden="true">${badge}</span>
      <span class="tt"><b>${hl(x.t, term)}</b>${x.m ? `<small>${hl(x.m, term)}</small>` : ''}</span>
      ${where ? `<span class="where"><span class="cat" style="background:${x.dept.color}"></span>${esc(x.dept.name)}</span>` : ''}
      <span class="kind">${KIND[ext] || esc(ext.toUpperCase())}</span>
      <a class="go" href="${esc(x.url)}"${external ? ' target="_blank" rel="noopener"' : ''} aria-label="${esc(x.t)}${external ? ' (opens in a new tab)' : ''}"></a>
      ${x.type === 'page' ? '' : `<button class="star" type="button" data-fav="${esc(x.key)}" aria-pressed="${fav}" aria-label="${fav ? 'Remove from' : 'Add to'} favourites">${icon(fav ? 'starOn' : 'star')}</button>`}
    </div>`;
  }

  function editRow(x) {
    const ext = x.type === 'doc' ? x.ext : x.type;
    const badge = BADGE[ext] || esc((x.ext || 'file').toUpperCase().slice(0, 4));
    const where = x.type === 'form' ? 'Form' : x.type === 'page' ? 'Opens ' + ((byDept[x.it.target] || {}).name || 'a folder') : x.type === 'doc' ? (x.url.startsWith('/files/') ? 'Uploaded file' : 'Linked file') : (KIND[ext] || 'Link');
    return `<div class="row editing" data-item="${x.it.id}">
      <span class="ft ${esc(ext)}" aria-hidden="true">${badge}</span>
      <span class="tt"><b>${esc(x.t)}${x.it.quick ? ' <span class="qtag">Quick action</span>' : ''}</b><small>${esc([x.m, where].filter(Boolean).join(' · '))}</small></span>
      ${itemTools(x.it.id)}
    </div>`;
  }
  const itemTools = id => `<span class="etools">
      <button class="eb" type="button" data-act="item-edit" data-item="${id}" title="Edit">${icon('rename')}<span>Edit</span></button>
      <button class="eb icon" type="button" data-act="item-up" data-item="${id}" title="Move up" aria-label="Move up">${icon('up')}</button>
      <button class="eb icon" type="button" data-act="item-down" data-item="${id}" title="Move down" aria-label="Move down">${icon('down')}</button>
      <button class="eb icon danger" type="button" data-act="item-del" data-item="${id}" title="Delete" aria-label="Delete">${icon('del')}</button></span>`;

  // ---------- views ----------
  function greeting() { const hr = new Date().getHours(); return hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening'; }
  // ---------- dashboard (the first page) ----------
  let DASH = null, taskTab = 'mine', ALLTASKS = null;
  const fmtDay = d => new Date(d + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
  const ago = iso => { const s = (Date.now() - new Date(iso)) / 1000; if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + ' min ago'; if (s < 86400) return Math.floor(s / 3600) + ' h ago'; if (s < 7 * 86400) return Math.floor(s / 86400) + ' d ago'; return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }); };
  function dueInfo(t) {
    if (!t.due) return '';
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const d = new Date(t.due + 'T00:00:00'), days = Math.round((d - today) / 864e5);
    const label = days === 0 ? 'Due today' : days === 1 ? 'Due tomorrow' : days < 0 ? `Overdue · ${fmtDay(t.due)}` : `Due ${fmtDay(t.due)}`;
    return `<span class="due${!t.done && days < 0 ? ' late' : !t.done && days <= 1 ? ' soon' : ''}">${icon('cal', 'i16')}${label}</span>`;
  }
  const linkAttrs = u => /^https?:/i.test(u) ? ` href="${esc(u)}" target="_blank" rel="noopener"` : ` href="${esc(u)}"`;
  function taskRow(t, showWho) {
    return `<li class="task${t.done ? ' done' : ''}" data-task="${t.id}">
      <button class="tick" type="button" data-done="${t.id}" role="checkbox" aria-checked="${t.done}" aria-label="${t.done ? 'Mark as not done' : 'Mark as done'}: ${esc(t.title)}">${icon('tick')}</button>
      <div class="tbody"><b>${esc(t.title)}</b>
        ${t.notes ? `<p>${esc(t.notes)}</p>` : ''}
        <div class="tmeta">${dueInfo(t)}${showWho ? `<span>${icon('person', 'i16')}${esc(t.assigneeName)}</span>` : t.createdBy && t.createdById !== ME.id ? `<span>From ${esc(t.createdBy)}</span>` : ''}${t.link ? `<a class="tlink"${linkAttrs(t.link)}>${icon('open', 'i16')}Open</a>` : ''}</div>
      </div>
      ${isAdminMe() ? `<span class="etools"><button class="eb icon" type="button" data-act="task-edit" data-task="${t.id}" title="Edit task" aria-label="Edit task">${icon('rename')}</button><button class="eb icon danger" type="button" data-act="task-del" data-task="${t.id}" title="Delete task" aria-label="Delete task">${icon('del')}</button></span>` : ''}
    </li>`;
  }
  function tasksHtml() {
    if (!DASH) return '<div class="dload"><span class="spinner"></span>Loading…</div>';
    const all = taskTab === 'all' && ALLTASKS;
    const list = all ? ALLTASKS : DASH.tasks;
    const open = list.filter(t => !t.done).sort((a, b) => (a.due || '9999').localeCompare(b.due || '9999'));
    const done = list.filter(t => t.done).sort((a, b) => (b.doneAt || '').localeCompare(a.doneAt || '')).slice(0, all ? 30 : 10);
    if (!list.length) return `<div class="dempty">${icon('tick', 'i big')}<b>${all ? 'No tasks yet' : 'You’re all caught up'}</b><span>${all ? 'Tasks you assign to people show here.' : 'Tasks assigned to you will show here.'}</span></div>`;
    return `${open.length ? `<ul class="tasks">${open.map(t => taskRow(t, all)).join('')}</ul>` : `<div class="dempty small">${icon('tick', 'i big')}<b>Nothing left to do</b></div>`}
      ${done.length ? `<details class="donebox"><summary>Done (${list.filter(t => t.done).length})</summary><ul class="tasks">${done.map(t => taskRow(t, all)).join('')}</ul></details>` : ''}`;
  }
  function newsHtml() {
    if (!DASH) return '<div class="dload"><span class="spinner"></span>Loading…</div>';
    if (!DASH.news.length) return `<div class="dempty">${icon('megaphone', 'i big')}<b>No announcements</b><span>${isAdminMe() ? 'Post one to share news with everyone.' : 'Company news will show here.'}</span></div>`;
    return `<ul class="news">${DASH.news.map(n => `<li class="ann${n.pinned ? ' pinned' : ''}">
      <div class="ahead"><b>${esc(n.title)}</b>${isAdminMe() ? `<span class="etools"><button class="eb icon" type="button" data-act="news-edit" data-news="${n.id}" title="Edit" aria-label="Edit announcement">${icon('rename')}</button><button class="eb icon danger" type="button" data-act="news-del" data-news="${n.id}" title="Delete" aria-label="Delete announcement">${icon('del')}</button></span>` : ''}</div>
      ${n.body ? `<p>${esc(n.body)}</p>` : ''}
      <div class="tmeta">${n.pinned ? `<span class="pin">${icon('pin', 'i16')}Pinned</span>` : ''}<span>${esc(n.by)} · ${ago(n.at)}</span>${n.link ? `<a class="tlink"${linkAttrs(n.link)}>${icon('open', 'i16')}Read more</a>` : ''}</div>
    </li>`).join('')}</ul>`;
  }
  function paintDash() {
    const t = $('#dTasks'), n = $('#dNews'); if (!t || !n) return;
    t.innerHTML = tasksHtml(); n.innerHTML = newsHtml();
    const c = $('#dTaskCount'); if (c && DASH) { const k = DASH.tasks.filter(x => !x.done).length; c.textContent = k ? k : ''; c.hidden = !k; }
    document.querySelectorAll('[data-tab]').forEach(b => b.setAttribute('aria-selected', b.dataset.tab === taskTab));
  }
  async function loadDash() {
    try {
      const r = await fetch('/api/dashboard'); if (r.status === 401) return toLogin();
      DASH = await r.json();
      if (taskTab === 'all' && isAdminMe()) { const a = await fetch('/api/admin/tasks'); if (a.ok) ALLTASKS = (await a.json()).tasks; }
    } catch { if (!DASH) { const t = $('#dTasks'); if (t) t.innerHTML = `<div class="bar-msg error">${icon('err')}<div>Couldn’t load your tasks. Check your connection.</div></div>`; return; } }
    paintDash();
  }
  async function toggleTask(id) {
    const find = l => (l || []).find(t => t.id === id);
    const t = find(DASH && DASH.tasks) || find(ALLTASKS); if (!t) return;
    const done = !t.done;
    [find(DASH.tasks), find(ALLTASKS)].forEach(x => { if (x) { x.done = done; x.doneAt = done ? new Date().toISOString() : null; } });
    paintDash();
    try {
      const r = await fetch(`/api/tasks/${id}/done`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ done }) });
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'That didn’t save.');
      if (done) toast(`${icon('check')}<span>Done: ${esc(t.title)}</span>`, 'ok');
    } catch (e) { toast(`${icon('err')}<span>${esc(e.message)}</span>`, 'error'); loadDash(); }
  }
  function viewHome() {
    const fv = favs.map(k => ITEMS.find(x => x.key === k)).filter(Boolean);
    const today = new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
    setTimeout(loadDash);
    const admin = isAdminMe();
    return `<section class="dash" aria-label="Dashboard">
      <div class="dhero"><p class="ddate">${esc(today)}</p><h1 class="dhello">${greeting()}, ${esc(ME ? ME.name : '')}</h1></div>
      <div class="dgrid">
        <section class="dcard" aria-labelledby="dTasksH">
          <header class="dch"><h2 id="dTasksH">${icon('tick')}My tasks <span class="badge" id="dTaskCount" hidden></span></h2>
            ${admin ? `<button class="btn subtle small" type="button" data-act="task-add">${icon('add')}Assign a task</button>` : ''}</header>
          ${admin ? `<div class="dtabs" role="tablist"><button type="button" role="tab" data-tab="mine" aria-selected="${taskTab === 'mine'}">Mine</button><button type="button" role="tab" data-tab="all" aria-selected="${taskTab === 'all'}">Everyone’s</button></div>` : ''}
          <div id="dTasks" class="dbody">${tasksHtml()}</div>
        </section>
        <section class="dcard" aria-labelledby="dNewsH">
          <header class="dch"><h2 id="dNewsH">${icon('megaphone')}Announcements</h2>
            ${admin ? `<button class="btn subtle small" type="button" data-act="news-add">${icon('add')}Post</button>` : ''}</header>
          <div id="dNews" class="dbody">${newsHtml()}</div>
        </section>
      </div>
    </section>
    <div class="pane-inner dash-rest">
      ${ITEMS.some(x => x.it.quick) ? `<h2 class="section" style="margin-top:4px">Quick actions</h2><div class="quick" style="margin-top:0">${ITEMS.filter(x => x.it.quick).map(x => `<a class="qa" href="${esc(x.url)}"><span class="tile">${icon('bolt')}</span><span><b>${esc(x.t)}</b><small>${esc(x.dept.name)}</small></span></a>`).join('')}</div>` : ''}
      ${ITEMS.some(x => x.type === 'app') ? `<h2 class="section">Apps</h2>
      <div class="quick" style="margin-top:0">${ITEMS.filter(x => x.type === 'app').map(x => `<a class="qa" href="${esc(x.url)}"><span class="tile">${icon('leaf')}</span><span><b>${esc(x.t)}</b><small>${esc(x.m || x.dept.name)}</small></span></a>`).join('')}</div>` : ''}
      ${fv.length ? `<h2 class="section">Favourites <span class="n">${fv.length}</span></h2><div class="list">${fv.map(x => row(x, { where: true })).join('')}</div>` : ''}
      <h2 class="section">Departments</h2>
      <div class="depts">${HOME.map(d => { const c = { form: 0, doc: 0, link: 0 }; ITEMS.filter(x => x.dept === d && c[x.type] != null).forEach(x => c[x.type]++);
        const parts = [c.form && `${c.form} form${c.form > 1 ? 's' : ''}`, c.doc && `${c.doc} document${c.doc > 1 ? 's' : ''}`, c.link && `${c.link} link${c.link > 1 ? 's' : ''}`].filter(Boolean);
        return `<a class="dept" href="#d/${d.id}"><span class="cat" style="background:${d.color}">${icon('folder')}</span><span><b>${esc(d.name)}</b><small>${parts.join(' · ')}</small></span></a>`; }).join('')}</div>
    </div>`;
  }
  function viewFav() {
    const fv = favs.map(k => ITEMS.find(x => x.key === k)).filter(Boolean);
    return `<div class="pane-inner"><h1 class="title">Favourites</h1><p class="subtitle">Star any form or document to keep it here. Favourites are saved in this browser.</p>
      <div style="margin-top:16px" class="list">${fv.length ? fv.map(x => row(x, { where: true })).join('') : `<div class="empty">No favourites yet. Select the star next to a form or document to add it.</div>`}</div></div>`;
  }
  function viewDept(d) {
    const sections = d.sections.map((s, si) => {
      const rows = ITEMS.filter(x => x.sec === s);
      let body = '', run = [];
      const flush = () => { if (run.length) { body += `<div class="list">${run.map(x => row(x)).join('')}</div>`; run = []; } };
      for (const it of s.items) {
        if (it.kind === 'note') { flush(); body += EDIT ? `<div class="note editing" data-item="${it.id}"><div class="ntext">${it.html || '<p><i>Empty note</i></p>'}</div>${itemTools(it.id)}</div>` : `<div class="note">${it.html}</div>`; }
        else run.push(rows.find(x => x.it === it));
      }
      flush();
      const head = EDIT
        ? `<div class="sechead"><h2 class="section">${s.title ? esc(s.title) : '<i>Untitled section</i>'}${rows.length ? ` <span class="n">${rows.length}</span>` : ''}</h2>
            <span class="etools"><button class="eb" type="button" data-act="sec-rename" data-sec="${s.id}">${icon('rename')}<span>Rename</span></button>
            <button class="eb icon" type="button" data-act="sec-up" data-sec="${s.id}" aria-label="Move section up" title="Move up"${si === 0 ? ' disabled' : ''}>${icon('up')}</button>
            <button class="eb icon" type="button" data-act="sec-down" data-sec="${s.id}" aria-label="Move section down" title="Move down"${si === d.sections.length - 1 ? ' disabled' : ''}>${icon('down')}</button>
            <button class="eb icon danger" type="button" data-act="sec-del" data-sec="${s.id}" aria-label="Delete section" title="Delete section">${icon('del')}</button></span></div>`
        : (s.title ? `<h2 class="section">${esc(s.title)}${rows.length ? ` <span class="n">${rows.length}</span>` : ''}</h2>` : '');
      const add = EDIT ? `<button class="addrow" type="button" data-act="item-add" data-sec="${s.id}">${icon('add')}Add to ${s.title ? '“' + esc(s.title) + '”' : 'this section'}</button>` : '';
      return `<section class="dsec" data-sec="${s.id}">${head}${body}${add}</section>`;
    }).join('');
    return `<div class="pane-inner">
      <div class="crumbs"><a href="#home">Home</a>${icon('chev', 'i16')}<span>${esc(d.name)}</span></div>
      <div class="dhead"><h1 class="title" style="display:flex;align-items:center;gap:10px"><span class="cat" style="background:${d.color};width:14px;height:14px"></span>${esc(d.name)}</h1>
        ${EDIT ? `<span class="etools"><button class="eb" type="button" data-act="dept-rename" data-dept="${d.id}">${icon('rename')}<span>Rename</span></button><button class="eb" type="button" data-act="dept-color" data-dept="${d.id}">${icon('palette')}<span>Colour</span></button><button class="eb danger" type="button" data-act="dept-del" data-dept="${d.id}">${icon('del')}<span>Delete folder</span></button></span>` : ''}</div>
      ${d.sections.length ? sections : `<div class="empty">This folder is empty.${EDIT ? '' : ''}</div>`}
      ${EDIT ? `<button class="addrow big" type="button" data-act="sec-add" data-dept="${d.id}">${icon('add')}Add a section</button>` : ''}
    </div>`;
  }
  let filter = 'all';
  function viewSearch(term) {
    const t = term.toLowerCase();
    let hits = ITEMS.filter(x => x.type !== 'page' && (x.t + ' ' + x.m + ' ' + x.sec.title + ' ' + x.dept.name + ' ' + (KIND[x.ext] || '')).toLowerCase().includes(t));
    const n = { all: hits.length, form: hits.filter(x => x.type === 'form').length, doc: hits.filter(x => x.type === 'doc').length, link: hits.filter(x => x.type === 'link').length };
    if (filter !== 'all') hits = hits.filter(x => x.type === filter);
    hits.sort((a, b) => b.t.toLowerCase().includes(t) - a.t.toLowerCase().includes(t));
    const chip = (k, l) => `<button class="chip" type="button" data-filter="${k}" aria-pressed="${filter === k}">${l} (${n[k]})</button>`;
    return `<div class="pane-inner"><h1 class="title">Results for “${esc(term)}”</h1>
      <div class="chips" style="margin-top:12px">${chip('all', 'All')}${chip('form', 'Forms')}${chip('doc', 'Documents')}${chip('link', 'Links')}</div>
      <div class="list">${hits.length ? hits.map(x => row(x, { where: true, term })).join('') : `<div class="empty">Nothing matches “${esc(term)}”. Try a shorter word, such as “toil” or “policy”.</div>`}</div></div>`;
  }

  // ---------- router ----------
  let formCtl = null, ED = null, lastHash = location.hash;
  async function route() {
    const term = q.value.trim();
    const hash = decodeURIComponent((location.hash || '#home').slice(1));
    if (ED && ED.canLeave && !hash.startsWith('edit-form/') && !ED.canLeave()) { history.replaceState(null, '', lastHash || '#home'); return; }
    lastHash = location.hash;
    $('#qClear').hidden = !term;
    document.body.classList.toggle('editing', EDIT);
    if (formCtl && !hash.startsWith('form/')) { formCtl.destroy(); formCtl = null; }
    if (term) { renderFolders(''); pane.innerHTML = viewSearch(term); return; }
    if (hash.startsWith('edit-form/') && isAdminMe()) {
      const id = hash.slice(10);
      renderFolders(formDept[id] ? formDept[id].dept.id : '');
      const ed = await editor(); return ed.builder(id);
    }
    if (hash.startsWith('form/')) {
      const id = hash.slice(5);
      renderFolders(formDept[id] ? formDept[id].dept.id : '');
      if (formCtl && formCtl.id === id) return;
      let def;
      try { def = await getForm(id); } catch (e) { if (e.message !== 'signed out') pane.innerHTML = `<div class="pane-inner"><div class="bar-msg error">${icon('err')}<div>The form could not be loaded. Check your connection and refresh the page.</div></div></div>`; return; }
      if (!def) { pane.innerHTML = `<div class="pane-inner"><div class="empty">This form could not be found. It may have been removed.<br><br><a class="btn" href="#home">Go to Home</a></div></div>`; return; }
      formCtl = renderForm(def); pane.scrollTop = 0; return;
    }
    if (hash.startsWith('d/') && byDept[hash.slice(2)]) { const d = byDept[hash.slice(2)]; renderFolders(d.id); pane.innerHTML = viewDept(d); }
    else if (hash === 'fav') { renderFolders('fav'); pane.innerHTML = viewFav(); }
    else { renderFolders('home'); pane.innerHTML = viewHome(); }
    if (EDIT) {
      const jot = ITEMS.filter(x => x.type === 'doc' && /jotform\.com/i.test(x.url)).length;
      pane.prepend(h('div', { class: 'editbar', html: `${icon('rename')}<span><b>Editing the hub.</b> Changes save straight away and show for everyone.</span>` },
        jot ? h('button', { class: 'btn subtle', type: 'button', 'data-act': 'import-docs', title: `${jot} documents are still stored on Jotform` }, `Copy ${jot} Jotform documents here`) : '',
        h('button', { class: 'btn', type: 'button', onclick: () => setEdit(false) }, 'Done')));
    }
    pane.scrollTop = 0;
  }
  function setEdit(on) {
    EDIT = !!on; store.set('wsh-edit', EDIT);
    const b = $('#editBtn'); if (b) { b.setAttribute('aria-pressed', EDIT); b.classList.toggle('on', EDIT); }
    if (formCtl) { formCtl.destroy(); formCtl = null; }
    route();
  }
  async function editor() {
    if (ED) return ED;
    if (!window.initHubEditor) await new Promise((ok, no) => { const sc = document.createElement('script'); sc.src = '/editor.js'; sc.onload = ok; sc.onerror = no; document.head.append(sc); });
    ED = window.initHubEditor({
      get hub() { return HUB; }, get byDept() { return byDept; }, get items() { return ITEMS; }, get formDept() { return formDept; },
      pane, folders, h, icon, esc, toast, route, setHub, getForm, loadFormList, get formList() { return FORM_LIST; }, FORMS, toLogin, renderFolders: () => renderFolders(activeFolder),
      closeMenu, openAt: placeMenu, loadDash, get dash() { return DASH; }, get allTasks() { return ALLTASKS; }, get me() { return ME; }
    });
    return ED;
  }
  let EDIT = false;
  window.addEventListener('hashchange', () => { if (!location.hash.startsWith('#form/')) q.value = ''; filter = 'all'; toggleMenu(false); route(); });
  q.addEventListener('input', () => { filter = 'all'; route(); });
  $('#qClear').addEventListener('click', () => { q.value = ''; route(); q.focus(); });
  document.addEventListener('keydown', e => {
    if (e.key === '/' && !/input|textarea|select/i.test(document.activeElement.tagName)) { e.preventDefault(); q.focus(); }
    if (e.key === 'Escape' && document.activeElement === q) { q.value = ''; route(); }
  });
  const onAct = async e => {
    const b = e.target.closest('[data-act]'); if (!b || !isAdminMe()) return false;
    e.preventDefault(); e.stopPropagation();
    const ed = await editor(); ed.act(b.dataset.act, b.dataset, b); return true;
  };
  folders.addEventListener('click', e => { if (e.target.closest('[data-act]')) onAct(e); }, true);
  pane.addEventListener('click', e => {
    if (e.target.closest('[data-act]')) { onAct(e); return; }
    const dn = e.target.closest('[data-done]');
    if (dn) { toggleTask(dn.dataset.done); return; }
    const tb = e.target.closest('[data-tab]');
    if (tb) { taskTab = tb.dataset.tab; if (taskTab === 'all' && !ALLTASKS) { $('#dTasks').innerHTML = tasksHtml(); loadDash(); } paintDash(); return; }
    const s = e.target.closest('[data-fav]');
    if (s) {
      const k = s.dataset.fav; favs = favs.includes(k) ? favs.filter(x => x !== k) : [...favs, k]; store.set('wsh-favs', favs);
      const on = favs.includes(k); s.setAttribute('aria-pressed', on); s.innerHTML = icon(on ? 'starOn' : 'star'); s.setAttribute('aria-label', (on ? 'Remove from' : 'Add to') + ' favourites');
      renderFolders(activeFolder);
      if (location.hash === '#fav' || (!location.hash || location.hash === '#home')) route();
      return;
    }
    const f = e.target.closest('[data-filter]');
    if (f) { filter = f.dataset.filter; route(); }
  });

  // ---------- folder right-click menu: open, rename, reset ----------
  let menu = null, adminState = null;
  async function isAdminUser() {
    return isAdminMe();
  }
  function toast(html, kind = 'info') {
    document.querySelectorAll('.toast').forEach(t => t.remove());
    const t = h('div', { class: 'toast ' + kind, role: 'status', html });
    t.append(h('button', { class: 'btn subtle', type: 'button', 'aria-label': 'Dismiss', html: icon('x', 'i16'), onclick: () => t.remove() }));
    document.body.append(t);
    setTimeout(() => t.remove(), 9000);
  }
  function closeMenu() { if (menu) { menu.remove(); menu = null; document.removeEventListener('pointerdown', outside, true); } }
  function outside(e) { if (menu && !menu.contains(e.target)) closeMenu(); }
  function placeMenu(m, x, y, anchor) {
    document.body.append(m);
    if (anchor && !x && !y) { const r = anchor.getBoundingClientRect(); x = r.left + 24; y = r.bottom; }
    m.style.left = Math.max(8, Math.min(x, innerWidth - m.offsetWidth - 8)) + 'px';
    m.style.top = Math.max(8, Math.min(y, innerHeight - m.offsetHeight - 8)) + 'px';
    const first = m.querySelector('.mi'); if (first) first.focus();
    menu = m;
    setTimeout(() => document.addEventListener('pointerdown', outside, true));
    m.addEventListener('keydown', e => {
      const items = [...m.querySelectorAll('.mi:not([disabled])')], i = items.indexOf(document.activeElement);
      if (e.key === 'Escape') { e.preventDefault(); closeMenu(); if (anchor) anchor.focus(); }
      if (e.key === 'ArrowDown') { e.preventDefault(); items[(i + 1) % items.length].focus(); }
      if (e.key === 'ArrowUp') { e.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); }
      if (e.key === 'Tab') closeMenu();
    });
  }
  async function openMenu(a, x, y) {
    closeMenu();
    if (isAdminMe()) { const ed = await editor(); return ed.deptMenu(a.dataset.dept, x, y, a); }
    const d = byDept[a.dataset.dept];
    const m = h('div', { class: 'ctxmenu', role: 'menu', 'aria-label': d.name + ' options' },
      h('button', { class: 'mi', type: 'button', role: 'menuitem', html: icon('folder') + '<span>Open</span>', onclick: () => { closeMenu(); location.hash = '#d/' + d.id; } }));
    placeMenu(m, x, y, a);
  }
  folders.addEventListener('contextmenu', e => {
    const a = e.target.closest('.folder[data-dept]'); if (!a) return;
    if (!isAdminMe()) return;
    e.preventDefault(); openMenu(a, e.clientX, e.clientY);
  });
  // long-press on touch screens
  let press = null, pressed = false;
  folders.addEventListener('pointerdown', e => {
    const a = e.target.closest('.folder[data-dept]'); if (!a || e.pointerType !== 'touch' || !isAdminMe()) return;
    press = setTimeout(() => { pressed = true; openMenu(a, e.clientX, e.clientY); }, 550);
  });
  ['pointerup', 'pointercancel', 'pointermove'].forEach(t => folders.addEventListener(t, () => clearTimeout(press)));
  folders.addEventListener('click', e => { if (pressed) { e.preventDefault(); pressed = false; } }, true);
  addEventListener('resize', closeMenu); pane.addEventListener('scroll', closeMenu);

  // ---------- account menu, change password ----------
  const meBtn = $('#meBtn');
  const initials = n => String(n || '?').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();
  function accountMenu() {
    closeMenu();
    const item = (ic, label, fn) => h('button', { class: 'mi', type: 'button', role: 'menuitem', html: icon(ic) + `<span>${esc(label)}</span>`, onclick: () => { closeMenu(); fn(); } });
    menu = h('div', { class: 'ctxmenu acct', role: 'menu', 'aria-label': 'Your account' },
      h('div', { class: 'who', html: `<span class="avatar big" aria-hidden="true">${esc(initials(ME.name))}</span><span><b>${esc(ME.name)}</b><small>${esc(ME.email)}</small><em>${ME.role === 'admin' ? 'Admin' : 'Viewer'}</em></span>` }),
      ME.passwordLogin !== false ? item('key', 'Change password', changePassword) : null,
      ME.microsoftLogin ? item('open', 'Microsoft security settings', () => { window.open('https://mysignins.microsoft.com/security-info', '_blank', 'noopener'); }) : null,
      isAdminMe() ? item('people', 'Manage users', () => { location.href = '/admin#users'; }) : null,
      isAdminMe() ? item('inbox', 'Submissions', () => { location.href = '/admin'; }) : null,
      h('div', { class: 'sep', role: 'separator' }),
      item('signout', 'Sign out', () => { location.href = '/logout'; }));
    document.body.append(menu);
    const r = meBtn.getBoundingClientRect();
    menu.style.top = (r.bottom + 6) + 'px';
    menu.style.left = Math.max(8, r.right - menu.offsetWidth) + 'px';
    menu.querySelector('.mi').focus();
    setTimeout(() => document.addEventListener('pointerdown', outside, true));
    menu.addEventListener('keydown', e => {
      const items = [...menu.querySelectorAll('.mi')], i = items.indexOf(document.activeElement);
      if (e.key === 'Escape') { closeMenu(); meBtn.focus(); }
      if (e.key === 'ArrowDown') { e.preventDefault(); items[(i + 1) % items.length].focus(); }
      if (e.key === 'ArrowUp') { e.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); }
      if (e.key === 'Tab') closeMenu();
    });
  }
  meBtn.addEventListener('click', () => (menu && menu.classList.contains('acct')) ? closeMenu() : accountMenu());

  function changePassword() {
    const ov = h('div', { class: 'overlay', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'cpT' });
    const box = h('form', { class: 'dialog', novalidate: true });
    const field = (id, label, ac) => h('div', { class: 'q', style: 'margin-top:14px' }, h('label', { for: id }, label), h('input', { id, class: 'ctl', type: 'password', autocomplete: ac }));
    const err = h('div', { role: 'alert' });
    box.append(h('h2', { id: 'cpT', class: 'dtitle' }, 'Change password'),
      h('p', { class: 'subtitle', style: 'margin:4px 0 0' }, 'Use at least 8 characters, including a number or symbol.'),
      err, field('cpCur', 'Current password', 'current-password'), field('cpNew', 'New password', 'new-password'), field('cpNew2', 'Type the new password again', 'new-password'),
      h('div', { class: 'cmdbar', style: 'justify-content:flex-end;margin-top:20px;gap:8px' },
        h('button', { class: 'btn', type: 'button', onclick: () => ov.remove() }, 'Cancel'),
        h('button', { class: 'btn primary', type: 'submit' }, 'Change password')));
    ov.append(box); document.body.append(ov); $('#cpCur').focus();
    ov.addEventListener('keydown', e => { if (e.key === 'Escape') ov.remove(); });
    ov.addEventListener('click', e => { if (e.target === ov) ov.remove(); });
    box.addEventListener('submit', async e => {
      e.preventDefault();
      const show = t => { err.className = 'bar-msg error'; err.innerHTML = icon('err') + `<div>${esc(t)}</div>`; };
      if ($('#cpNew').value !== $('#cpNew2').value) return show('The two new passwords don’t match.');
      try {
        const r = await fetch('/api/me/password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ current: $('#cpCur').value, password: $('#cpNew').value }) });
        const out = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(out.error || 'Your password couldn’t be changed.');
        ov.remove(); toast(`${icon('check')}<span>Password changed. You’ve been signed out on your other devices.</span>`, 'ok');
      } catch (x) { show(x.message); }
    });
  }

  async function loadMe() {
    try {
      const r = await fetch('/api/me');
      if (r.status === 401) { toLogin(); return false; }
      ME = await r.json();
    } catch { return true; }
    meBtn.textContent = initials(ME.name); meBtn.hidden = false; meBtn.title = `${ME.name} (${ME.role === 'admin' ? 'Admin' : 'Viewer'})`;
    $('#inboxLink').hidden = !isAdminMe();
    const eb = $('#editBtn'); if (eb) eb.hidden = !isAdminMe();
    if (isAdminMe()) { EDIT = !!store.get('wsh-edit', false); if (eb) { eb.setAttribute('aria-pressed', EDIT); eb.classList.toggle('on', EDIT); eb.onclick = () => setEdit(!EDIT); } }
    const qs = new URLSearchParams(location.search);
    if (qs.get('account') && ME.passwordLogin !== false) changePassword();
    if (qs.get('notice') === 'admin-only') toast(`${icon('info')}<span>That page is for admins. Ask an admin if you need access.</span>`);
    if (qs.toString()) history.replaceState(null, '', location.pathname + location.hash);
    renderFolders(activeFolder);
    return true;
  }

  // =====================================================================
  // Form renderer
  // =====================================================================
  const E = window.FormEngine;
  const SEG_MAX = 4;
  function renderForm(def) {
    const draftKey = 'wsh-draft-' + def.id;
    const values = store.get(draftKey, {}) || {};
    const files = {}; // id -> File[]
    const wraps = {};
    const info = formDept[def.id];
    let sending = false;

    const root = h('div', { class: 'pane-inner' });
    const wrap = h('div', { class: 'formwrap' });
    const heads = def.fields.filter(f => f.type === 'head');
    const titleField = heads[0] && def.fields.indexOf(heads[0]) < 2 ? heads[0] : null;
    root.append(
      h('div', { class: 'crumbs', html: `<a href="#home">Home</a>${icon('chev', 'i16')}${info ? `<a href="#d/${info.dept.id}">${esc(info.dept.name)}</a>${icon('chev', 'i16')}` : ''}<span>${esc(def.name)}</span>` }),
      h('div', { class: 'form-head' },
        isAdminMe() ? h('a', { class: 'btn editform', href: '#edit-form/' + def.id, html: icon('rename') + 'Edit form' }) : null,
        h('h1', { class: 'title' }, titleField ? (titleField.label || def.name) : def.name),
        titleField && titleField.sub ? h('p', { class: 'subtitle' }, titleField.sub) : null)
    );
    const restored = Object.keys(values).length > 0;
    const draftNote = restored ? h('div', { class: 'bar-msg warn', html: `${icon('info')}<div style="flex:1">You have unsent answers from earlier. They are filled in below.</div>` }) : null;
    if (draftNote) { const b = h('button', { class: 'btn subtle', type: 'button', onclick: () => { clearAll(); } }, 'Start again'); draftNote.append(b); wrap.append(draftNote); }

    const form = h('form', { novalidate: true, autocomplete: 'on' });
    form.append(h('input', { class: 'hp', name: 'website', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' }));
    const errBox = h('div', { hidden: true, role: 'alert' });
    form.append(errBox);

    let n = 0;
    for (const f of def.fields) {
      if (f === titleField) continue;
      const el = renderField(f, ++n);
      if (el) { wraps[f.id] = el; form.append(el); }
    }
    const status = h('span', { class: 'status', 'aria-live': 'polite' });
    const submitBtn = h('button', { class: 'btn primary large', type: 'submit' }, 'Submit');
    form.append(h('div', { class: 'submitbar' }, submitBtn, h('button', { class: 'btn subtle', type: 'button', onclick: () => clearAll() }, 'Clear form'), status));
    form.addEventListener('submit', onSubmit);
    wrap.append(form); root.append(wrap);
    pane.innerHTML = ''; pane.append(root);
    refresh();

    function save() {
      const keep = {}; for (const [k, v] of Object.entries(values)) if (!E.isEmpty(v)) keep[k] = v;
      if (Object.keys(keep).length) { store.set(draftKey, keep); status.textContent = 'Draft saved on this device'; } else store.del(draftKey);
    }
    function set(id, v) { values[id] = v; refresh(); save(); clearErr(id); }
    function refresh() {
      const vis = E.visibleFields(def, values);
      for (const [id, el] of Object.entries(wraps)) el.hidden = !vis.has(id);
      for (const f of def.fields.filter(f => f.type === 'calculation')) { const o = wraps[f.id] && wraps[f.id].querySelector('.calc'); if (o) o.textContent = E.calc(def, f, values); }
    }
    function clearErr(id) { const w = wraps[id]; if (w && w.classList.contains('err')) { w.classList.remove('err'); const m = w.querySelector('.msg'); if (m) m.remove(); } }
    function clearAll() {
      store.del(draftKey); for (const k of Object.keys(values)) delete values[k];
      for (const k of Object.keys(files)) delete files[k];
      formCtl = null; formCtl = renderForm(def); pane.scrollTop = 0;
    }

    // ----- individual fields -----
    function labelFor(f, forId, asLegend) {
      const text = f.label || '';
      if (!text) return null;
      const L = h(asLegend ? 'legend' : 'label', asLegend ? {} : { for: forId }, text);
      if (f.required) L.append(h('span', { class: 'req', 'aria-hidden': 'true' }, '*'));
      return L;
    }
    function renderField(f, i) {
      const id = 'f' + def.id.slice(-4) + '_' + f.id;
      const v = values[f.id];
      const req = f.required ? true : null;
      switch (f.type) {
        case 'head': {
          if (!f.label && !f.sub) return null;
          return h('div', { class: 'fsec' }, f.label ? h('h3', {}, f.label) : null, f.sub ? h('p', {}, f.sub) : null);
        }
        case 'divider': return h('hr', { class: 'fdiv' });
        case 'text': return h('div', { class: 'info', html: icon('info') + `<div>${esc(f.html)}</div>` });
        case 'textbox': case 'email': case 'number': case 'phone': {
          const input = h('input', { id, class: 'ctl', type: { email: 'email', number: 'number', phone: 'tel' }[f.type] || 'text', placeholder: f.placeholder, required: req, autocomplete: f.type === 'email' ? 'email' : f.type === 'phone' ? 'tel' : 'off', inputmode: f.type === 'number' ? 'decimal' : null });
          input.value = v || ''; input.addEventListener('input', () => set(f.id, input.value));
          return h('div', { class: 'q' }, labelFor(f, id), input);
        }
        case 'textarea': {
          const t = h('textarea', { id, class: 'ctl', required: req, rows: 3 }); t.value = v || '';
          t.addEventListener('input', () => set(f.id, t.value));
          return h('div', { class: 'q' }, labelFor(f, id), t);
        }
        case 'fullname': {
          const parts = f.parts || ['First name', 'Last name'];
          const cur = v || {};
          const a = h('input', { id, class: 'ctl', autocomplete: f.parts ? 'off' : 'given-name' }), b = h('input', { id: id + 'b', class: 'ctl', autocomplete: f.parts ? 'off' : 'family-name' });
          a.value = cur.first || ''; b.value = cur.last || '';
          const upd = () => set(f.id, { first: a.value, last: b.value });
          a.addEventListener('input', upd); b.addEventListener('input', upd);
          return h('fieldset', { class: 'q' }, labelFor(f, id, true),
            h('div', { class: 'grid2' }, h('div', {}, a, h('div', { class: 'sub' }, parts[0])), h('div', {}, b, h('div', { class: 'sub' }, parts[1] || 'Last name'))));
        }
        case 'address': {
          const cur = v || {};
          const keys = [['street', 'Street address', 'address-line1'], ['line2', 'Address line 2', 'address-line2'], ['city', 'Town or city', 'address-level2'], ['region', 'County / state', 'address-level1'], ['postcode', 'Postcode', 'postal-code']];
          if ((f.parts || []).includes('Country')) keys.push(['country', 'Country', 'country-name']);
          const inputs = keys.map(([k, lab, ac], j) => { const x = h('input', { id: j ? id + k : id, class: 'ctl', autocomplete: ac }); x.value = cur[k] || ''; x.addEventListener('input', () => set(f.id, Object.fromEntries(keys.map(([kk], jj) => [kk, inputs[jj].value])))); return [x, lab]; });
          const cell = ([x, lab]) => h('div', {}, x, h('div', { class: 'sub' }, lab));
          return h('fieldset', { class: 'q' }, labelFor(f, id, true), h('div', { class: 'grid2' },
            h('div', { style: 'grid-column:1/-1' }, ...cell(inputs[0]).childNodes), h('div', { style: 'grid-column:1/-1' }, ...cell(inputs[1]).childNodes), ...inputs.slice(2).map(cell)));
        }
        case 'date': case 'datetime': {
          const x = h('input', { id, class: 'ctl', type: f.type === 'date' ? 'date' : 'datetime-local', required: req }); x.value = v || '';
          x.addEventListener('change', () => set(f.id, x.value)); x.addEventListener('input', () => set(f.id, x.value));
          return h('div', { class: 'q' }, labelFor(f, id), x);
        }
        case 'time': {
          const cur = v || {};
          const a = h('input', { id, class: 'ctl', type: 'time' }); a.value = cur.from || '';
          const parts = [a];
          let b = null;
          if (f.range) { b = h('input', { id: id + 'to', class: 'ctl', type: 'time', 'aria-label': 'Until' }); b.value = cur.to || ''; }
          const upd = () => set(f.id, b ? { from: a.value, to: b.value } : { from: a.value });
          a.addEventListener('input', upd); if (b) b.addEventListener('input', upd);
          return h('div', { class: 'q' }, labelFor(f, id), h('div', { class: 'timepair' }, a, b ? h('span', { style: 'color:var(--fg-3)' }, 'until') : null, b));
        }
        case 'dropdown': {
          const s = h('select', { id, class: 'ctl', required: req }, h('option', { value: '' }, 'Select an option'), ...f.options.map(o => h('option', { value: o }, o)));
          s.value = v || ''; s.addEventListener('change', () => set(f.id, s.value));
          return h('div', { class: 'q' }, labelFor(f, id), s);
        }
        case 'radio': case 'checkbox': {
          const multi = f.type === 'checkbox';
          const opts = f.options || [];
          const short = !multi && opts.length <= SEG_MAX && opts.every(o => o.length <= 14);
          const cur = multi ? (Array.isArray(v) ? v : []) : (v || '');
          const curPlain = multi ? cur.map(x => x.startsWith('Other:') ? 'Other' : x) : (String(cur).startsWith('Other:') ? 'Other' : cur);
          const otherVal = (multi ? cur.find(x => x.startsWith('Other:')) : (String(cur).startsWith('Other:') ? cur : '')) || '';
          const box = h('div', { class: short ? 'seg' : 'opts', role: multi ? 'group' : 'radiogroup' });
          const other = f.other ? h('input', { class: 'ctl other', placeholder: 'Type your answer', 'aria-label': 'Other answer', hidden: true }) : null;
          if (other) other.value = otherVal.replace(/^Other:\s*/, '');
          const read = () => {
            const checked = [...box.querySelectorAll('input:checked')].map(x => x.value);
            if (other) other.hidden = !checked.includes('Other');
            const map = x => x === 'Other' && other && other.value.trim() ? 'Other: ' + other.value.trim() : x;
            set(f.id, multi ? checked.map(map) : (checked[0] ? map(checked[0]) : ''));
          };
          opts.forEach((o, j) => {
            const inp = h('input', { type: multi ? 'checkbox' : 'radio', name: id, value: o, id: id + '_' + j });
            inp.checked = multi ? curPlain.includes(o) : curPlain === o;
            inp.addEventListener('change', read);
            box.append(short ? h('label', { for: id + '_' + j }, inp, h('span', {}, o)) : h('label', { class: 'opt', for: id + '_' + j }, inp, h('span', {}, o)));
          });
          if (other) { other.hidden = !(multi ? curPlain.includes('Other') : curPlain === 'Other'); other.addEventListener('input', read); }
          const fs = h('fieldset', { class: 'q' }, labelFor(f, id, true), box, other);
          if (!f.label && opts.length === 1) fs.querySelector('legend')?.remove();
          return fs;
        }
        case 'rating': {
          const max = f.max || 5, box = h('div', { class: 'stars', role: 'radiogroup', 'aria-label': f.label });
          const paint = () => [...box.children].forEach((b, j) => { b.classList.toggle('on', j < Number(values[f.id] || 0)); b.setAttribute('aria-checked', String(j + 1) === String(values[f.id])); });
          for (let j = 1; j <= max; j++) box.append(h('button', { type: 'button', role: 'radio', 'aria-label': `${j} of ${max}`, html: `<svg viewBox="0 0 20 20"><path d="${P.starOn}"/></svg>`, onclick: () => { set(f.id, String(j) === String(values[f.id]) ? '' : String(j)); paint(); } }));
          paint();
          return h('fieldset', { class: 'q' }, labelFor(f, id, true), box);
        }
        case 'scale': {
          const max = f.max || 10, box = h('div', { class: 'seg scale', role: 'radiogroup' });
          for (let j = 1; j <= max; j++) {
            const inp = h('input', { type: 'radio', name: id, value: String(j), id: id + '_' + j }); inp.checked = String(v) === String(j);
            inp.addEventListener('change', () => set(f.id, String(j)));
            box.append(h('label', { for: id + '_' + j }, inp, h('span', {}, String(j))));
          }
          return h('fieldset', { class: 'q' }, labelFor(f, id, true), box, h('div', { class: 'hint', style: 'margin-top:4px' }, `1 = lowest, ${max} = highest`));
        }
        case 'calculation':
          return h('div', { class: 'q' }, h('label', {}, f.label || 'Total'), h('output', { class: 'calc' }, '0'));
        case 'file': return fileField(f, id);
        case 'signature': return sigField(f, id);
        case 'products': return productsField(f, id);
        default: return null;
      }
    }

    function fileField(f, id) {
      const list = h('ul', { class: 'files' });
      const input = h('input', { id, type: 'file', multiple: true });
      const box = h('label', { class: 'filebox', for: id },
        h('span', { class: 'btn', html: icon('upload') + 'Choose files' }),
        h('span', { class: 'hint2' }, 'Or drag files here. Photos from your phone camera work too. Up to 25 MB each.'), input);
      const paint = () => {
        list.innerHTML = '';
        (files[f.id] || []).forEach((file, j) => {
          const li = h('li', {});
          if (/^image\//.test(file.type)) { const img = h('img', { alt: '' }); img.src = URL.createObjectURL(file); li.append(img); }
          li.append(h('span', { class: 'nm' }, file.name), h('span', { class: 'sz' }, (file.size / 1048576).toFixed(1) + ' MB'),
            h('button', { class: 'btn subtle', type: 'button', 'aria-label': 'Remove ' + file.name, html: icon('x', 'i16'), onclick: () => { files[f.id].splice(j, 1); paint(); } }));
          list.append(li);
        });
      };
      const add = fl => {
        const arr = files[f.id] = files[f.id] || [];
        for (const file of fl) { if (file.size > 25 * 1048576) { showFieldErr(f.id, `${file.name} is over 25 MB. Choose a smaller file.`); continue; } arr.push(file); }
        paint(); clearErr(f.id);
      };
      input.addEventListener('change', () => { add(input.files); input.value = ''; });
      box.addEventListener('dragover', e => { e.preventDefault(); box.classList.add('drag'); });
      box.addEventListener('dragleave', () => box.classList.remove('drag'));
      box.addEventListener('drop', e => { e.preventDefault(); box.classList.remove('drag'); add(e.dataTransfer.files); });
      return h('div', { class: 'q' }, labelFor(f, id) || h('label', { for: id }, 'Upload files'), box, list);
    }

    function sigField(f, id) {
      const canvas = h('canvas', { id, 'aria-label': 'Signature pad. Draw your signature with a mouse, finger or pen.' });
      const pad = h('div', { class: 'sig' }, canvas, h('div', { class: 'line' }), h('div', { class: 'ph' }, 'Sign above the line'));
      let ctx, drawing = false, dirty = !!values[f.id];
      const setup = () => {
        const r = canvas.getBoundingClientRect(); if (!r.width) return;
        const dpr = window.devicePixelRatio || 1;
        canvas.width = r.width * dpr; canvas.height = 160 * dpr;
        ctx = canvas.getContext('2d'); ctx.scale(dpr, dpr); ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#1B1B1B';
        if (values[f.id]) { const img = new Image(); img.onload = () => ctx.drawImage(img, 0, 0, r.width, 160); img.src = values[f.id]; }
      };
      requestAnimationFrame(setup);
      const pos = e => { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
      canvas.addEventListener('pointerdown', e => { if (!ctx) setup(); drawing = true; canvas.setPointerCapture(e.pointerId); const [x, y] = pos(e); ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + .1, y + .1); ctx.stroke(); });
      canvas.addEventListener('pointermove', e => { if (!drawing) return; const [x, y] = pos(e); ctx.lineTo(x, y); ctx.stroke(); });
      const end = () => { if (!drawing) return; drawing = false; dirty = true; set(f.id, canvas.toDataURL('image/png')); };
      canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end);
      const clear = h('button', { class: 'btn subtle', type: 'button', html: icon('eraser') + 'Clear signature', onclick: () => { if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height); dirty = false; set(f.id, ''); } });
      return h('div', { class: 'q' }, labelFor(f, id) || h('label', { for: id }, 'Signature'), pad, h('div', { class: 'sigtools' }, clear));
    }

    function productsField(f, id) {
      const cur = (values[f.id] && values[f.id].items) || {};
      const box = h('div', { class: 'products', role: 'group', 'aria-label': f.label });
      const write = () => set(f.id, { items: JSON.parse(JSON.stringify(cur)) });
      f.products.forEach((p, j) => {
        const it = cur[p.name];
        const out = h('output', {}, String(it ? it.qty : 0));
        const optsBox = h('div', { class: 'po', hidden: !it || !p.opts.length });
        const rowEl = h('div', { class: 'prod' + (it ? ' on' : '') });
        const setQty = qn => {
          qn = Math.max(0, Math.min(p.max, qn));
          if (qn === 0) delete cur[p.name]; else cur[p.name] = { qty: qn, opts: (cur[p.name] && cur[p.name].opts) || {} };
          out.textContent = qn; rowEl.classList.toggle('on', qn > 0); optsBox.hidden = !(qn > 0 && p.opts.length); write();
        };
        p.opts.forEach(o => {
          const s = h('select', { class: 'ctl' }, h('option', { value: '' }, 'Choose'), ...o.values.map(x => h('option', { value: x }, x)));
          s.value = (it && it.opts[o.name]) || '';
          s.addEventListener('change', () => { if (cur[p.name]) { cur[p.name].opts[o.name] = s.value; write(); } });
          optsBox.append(h('label', {}, o.name, s));
        });
        rowEl.append(h('div', { class: 'pn' }, p.name, p.max > 1 ? h('div', { class: 'hint', style: 'margin:2px 0 0;font-weight:400' }, `Up to ${p.max}`) : null),
          h('div', { class: 'stepper' }, h('button', { type: 'button', 'aria-label': 'Fewer ' + p.name, onclick: () => setQty(Number(out.textContent) - 1) }, '−'), out,
            h('button', { type: 'button', 'aria-label': 'More ' + p.name, onclick: () => setQty(Number(out.textContent) + 1) }, '+')), optsBox);
        box.append(rowEl);
      });
      return h('fieldset', { class: 'q' }, labelFor(f, id, true), box);
    }

    function showFieldErr(fid, msg) {
      const w = wraps[fid]; if (!w) return;
      w.classList.add('err'); const old = w.querySelector('.msg'); if (old) old.remove();
      w.append(h('div', { class: 'msg', html: icon('err', 'i16') + esc(msg) }));
    }

    async function onSubmit(e) {
      e.preventDefault();
      if (sending) return;
      Object.keys(wraps).forEach(clearErr); errBox.hidden = true;
      // products must have a size picked where one is offered
      const fileCounts = Object.fromEntries(Object.entries(files).map(([k, v]) => [k, v.length]));
      const { errors } = E.validate(def, values, fileCounts);
      for (const f of def.fields.filter(f => f.type === 'products')) {
        const items = (values[f.id] && values[f.id].items) || {};
        const p = f.products.find(p => items[p.name] && p.opts.some(o => !items[p.name].opts[o.name]));
        if (p) errors[f.id] = `Choose the ${p.opts.map(o => o.name.toLowerCase()).join(' and ')} for ${p.name}.`;
      }
      const ids = Object.keys(errors);
      if (ids.length) {
        ids.forEach(id => showFieldErr(id, errors[id]));
        errBox.className = 'bar-msg error'; errBox.innerHTML = icon('err') + `<div>${ids.length === 1 ? 'One answer needs' : ids.length + ' answers need'} attention before you can submit.</div>`; errBox.hidden = false;
        const first = wraps[ids[0]]; if (first) { first.scrollIntoView({ block: 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); const c = first.querySelector('input,textarea,select,button,canvas'); if (c) c.focus({ preventScroll: true }); }
        return;
      }
      sending = true; submitBtn.disabled = true; submitBtn.innerHTML = '<span class="spinner"></span> Sending…';
      const fd = new FormData();
      fd.append('data', JSON.stringify(values));
      fd.append('website', form.querySelector('.hp').value);
      const vis = E.visibleFields(def, values);
      for (const [fid, list] of Object.entries(files)) if (vis.has(fid)) list.forEach(file => fd.append('file_' + fid, file, file.name));
      try {
        const r = await fetch(`/api/forms/${def.id}/submit`, { method: 'POST', body: fd });
        if (r.status === 401) throw new Error('You’ve been signed out. Open the hub in a new tab, sign in, then come back and press Submit again.');
        const out = await r.json().catch(() => ({}));
        if (!r.ok) {
          if (out.fields) Object.entries(out.fields).forEach(([k, m]) => showFieldErr(k, m));
          throw new Error(out.error || 'The form could not be sent.');
        }
        store.del(draftKey);
        pane.scrollTop = 0;
        root.innerHTML = '';
        root.append(h('div', { class: 'done' },
          h('div', { class: 'tick', html: icon('check') }),
          h('h1', { class: 'title' }, 'Thanks, that’s been sent'),
          h('p', { class: 'subtitle', style: 'margin:8px auto 0' }, `${def.name} was received. Quote this reference if you need to follow it up:`),
          h('div', { class: 'ref' }, out.ref),
          h('div', { class: 'cmdbar', style: 'justify-content:center' },
            h('button', { class: 'btn primary', type: 'button', onclick: () => clearAll() }, 'Fill in another'),
            h('a', { class: 'btn', href: info ? '#d/' + info.dept.id : '#home' }, info ? 'Back to ' + info.dept.name : 'Back to Home'))));
      } catch (err) {
        errBox.className = 'bar-msg error'; errBox.innerHTML = icon('err') + `<div>${esc(err.message)} Your answers are still here, so you can try again.</div>`; errBox.hidden = false;
        errBox.scrollIntoView({ block: 'center' });
      } finally { sending = false; submitBtn.disabled = false; submitBtn.textContent = 'Submit'; }
    }

    return { id: def.id, destroy() { } };
  }

  loadMe().then(async ok => {
    if (!ok) return;
    try { await loadHub(); } catch (e) { if (e.message !== 'signed out') pane.innerHTML = `<div class="pane-inner"><div class="bar-msg error">${icon('err')}<div>The hub couldn’t be loaded. Check your connection and refresh the page.</div></div></div>`; return; }
    route();
  });
})();
